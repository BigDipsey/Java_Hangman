package ch.bruhin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class App {
    private JPanel panel1;
    private JTextField guessLetterTextField;
    private JButton button1;
    private JLabel wordToGuess;
    private JLabel wrongInputs;
    private JLabel wrongLetters;
    private JLabel Bilder;
    private int tries = 0;
    private int wrongTries = 0;
    private String[] words = {
            "hangman", "computer", "programming", "java", "developer",
            "game", "player", "music", "keyboard", "language",
    };
    private String word;

    public App() {
        setImage();
        chooseRandomWord();

        StringBuilder maskedWordBuilder = new StringBuilder();
        for (int i = 0; i < word.length(); i++) {
            maskedWordBuilder.append("_ ");
        }
        wordToGuess.setText(maskedWordBuilder.toString());

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String guess = guessLetterTextField.getText().toLowerCase();

                if (guess.length() == 1) {
                    handleLetterGuess(guess);
                } else if (guess.length() == word.length()) {
                    handleWordGuess(guess);
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter either a single letter or the full word.");
                }
            }
        });
    }

    private void chooseRandomWord() {
        Random random = new Random();
        word = words[random.nextInt(words.length)];
    }

    private void handleLetterGuess(String guess) {
        // ChatGPT kam half uns maskedWordBuilder zu verwenden um die darstellung der "_" zu dem eigentlichen Buchstaben zu ändern
        if (word.contains(guess)) {
            StringBuilder maskedWordBuilder = new StringBuilder(wordToGuess.getText());
            for (int i = 0; i < word.length(); i++) {
                if (word.charAt(i) == guess.charAt(0)) {
                    maskedWordBuilder.setCharAt(i * 2, guess.charAt(0));
                }
            }
            wordToGuess.setText(maskedWordBuilder.toString());
            if (!maskedWordBuilder.toString().contains("_")) {
                gameOver("Congratulations! You won!");
            }
        } else {
            wrongTries++;
            tries++;
            wrongInputs.setText("Amount of Wrong Tries: " + tries + "/" + 10);
            String currentWrongLetters = wrongLetters.getText();
            currentWrongLetters += guess + " ";
            wrongLetters.setText(currentWrongLetters);
            setImage();
            if (tries >= 10) {
                gameOver("You lost! The word was: " + word);
            }
        }
        guessLetterTextField.setText("");
    }

    private void handleWordGuess(String guess) {
        if (guess.equals(word)) {
            gameOver("Congratulations! You won!");
        } else {
            tries++;
            wrongInputs.setText("Amount of Wrong Tries: " + tries + "/" + 10);
            if (tries >= 10) {
                gameOver("You lost! The word was: " + word);
            }
        }
        guessLetterTextField.setText("");
    }

    private void gameOver(String message) {
        JOptionPane.showMessageDialog(null, message);
        int option = JOptionPane.showConfirmDialog(null, "Do you want to play again?", "Play Again", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            resetGame();
        } else {
            System.exit(0);
        }
    }

    private void resetGame() {
        tries = 0;
        wrongTries = 0;
        wrongInputs.setText("");
        wrongLetters.setText("");
        chooseRandomWord();
        StringBuilder maskedWordBuilder = new StringBuilder();
        for(int i = 0; i < word.length(); i++) {
            maskedWordBuilder.append("_ ");
        }
        wordToGuess.setText(maskedWordBuilder.toString());
        setImage();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Hangman");
        frame.setContentPane(new App().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(900, 700);
        frame.setVisible(true);
    }

    private void setImage () {
        String path = "src/Pictures/" + wrongTries + ".png";
        ImageIcon icon = new ImageIcon(path);
        Image image = icon.getImage().getScaledInstance(300,300, Image.SCALE_SMOOTH);
        icon = new ImageIcon(image);
        Bilder.setIcon(icon);
    }
}
